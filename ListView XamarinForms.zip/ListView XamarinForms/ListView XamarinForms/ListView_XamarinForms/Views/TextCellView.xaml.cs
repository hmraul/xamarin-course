﻿using ListView_XamarinForms.ViewModels;
using Xamarin.Forms;

namespace ListView_XamarinForms.Views
{
    public partial class TextCellView : ContentPage
    {
        public TextCellView()
        {
            InitializeComponent();

            BindingContext = new TextCellViewModel();
        }
    }
}