﻿using ListView_XamarinForms.ViewModels;
using Xamarin.Forms;

namespace ListView_XamarinForms.Views
{
    public partial class BasicView : ContentPage
    {
        private object Parameter { get; set; }

        private string[] Monkeys = 
            {
              "Baboon",
              "Capuchin Monkey",
              "Blue Monkey",
              "Squirrel Monkey",
              "Golden Lion Tamarin",
              "Howler Monkey",
              "Japanese Macaque",
              "Mandrill",
              "mononucleosis"
            };

        public BasicView()
        {
            InitializeComponent();

            BindingContext = new BasicViewModel();
        }

        protected override void OnAppearing()
        {
            BasicListView.ItemsSource = Monkeys;
        }
    }
}
