﻿using ListView_XamarinForms.ViewModels;
using Xamarin.Forms;

namespace ListView_XamarinForms.Views
{
    public partial class ImageCellView : ContentPage
    {
        public ImageCellView()
        {
            InitializeComponent();

            BindingContext = new ImageCellViewModel();
        }
    }
}
