﻿using ListView_XamarinForms.Services.Navigation;
using System.Windows.Input;
using Xamarin.Forms;

namespace ListView_XamarinForms.ViewModels
{
    public class MainViewModel : BindableObject
    {
        private ICommand _basicCommand;
        private ICommand _dataBindCommand;
        private ICommand _imageCellCommand;
        private ICommand _textCellCommand;

        public ICommand BasicCommand
        {
            get { return _basicCommand = _basicCommand ?? new Command(BasicCommandExecute); }
        }

        public ICommand DataBindCommand
        {
            get { return _dataBindCommand = _dataBindCommand ?? new Command(DataBindCommandExecute); }
        }

        public ICommand ImageCellCommand
        {
            get { return _imageCellCommand = _imageCellCommand ?? new Command(ImageCellCommandExecute); }
        }

        public ICommand TextCellCommand
        {
            get { return _textCellCommand = _textCellCommand ?? new Command(TextCellCommandExecute); }
        }

        private void BasicCommandExecute()
        {
            NavigationService.Instance.NavigateTo<BasicViewModel>();
        }

        private void DataBindCommandExecute()
        {
            NavigationService.Instance.NavigateTo<DataBindingViewModel>();
        }

        private void ImageCellCommandExecute()
        {
            NavigationService.Instance.NavigateTo<ImageCellViewModel>();
        }

        private void TextCellCommandExecute()
        {
            NavigationService.Instance.NavigateTo<TextCellViewModel>();
        }
    }
}
