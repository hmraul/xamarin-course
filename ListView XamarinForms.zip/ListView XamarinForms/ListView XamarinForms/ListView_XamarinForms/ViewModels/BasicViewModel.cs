﻿using Xamarin.Forms;

namespace ListView_XamarinForms.ViewModels
{
    public class BasicViewModel : BindableObject
    {
    }
}
