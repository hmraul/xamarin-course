﻿using Xamarin.Forms;

namespace XamarinFormsPreviewer
{
	public partial class MainView : ContentPage
	{
		public MainView()
		{
			InitializeComponent();
		}
	}
}

