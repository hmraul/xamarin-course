﻿using Xamarin.Forms;

namespace Xamarin_Forms_Layouts.Views
{
    public class MainView : ContentPage
    {
        public MainView()
        {
            Label header = new Label
            {
                Text = "Xamarin.Forms Layouts",
                FontSize = 40,
                FontAttributes = FontAttributes.Bold,
                HorizontalOptions = LayoutOptions.Center
            };

            Button stackLayout = new Button
            {
                Text = " StackLayout ",
                Font = Font.SystemFontOfSize(NamedSize.Large),
                BorderWidth = 1
            };

            stackLayout.Clicked += async (sender, args) =>
                await Navigation.PushAsync(new StackLayoutView());

            Button grid = new Button
            {
                Text = " Grid ",
                Font = Font.SystemFontOfSize(NamedSize.Large),
                BorderWidth = 1
            };

            grid.Clicked += async (sender, args) =>
                await Navigation.PushAsync(new GridView());

            Button relativeLayout = new Button
            {
                Text = " RelativeLayout ",
                Font = Font.SystemFontOfSize(NamedSize.Large),
                BorderWidth = 1
            };

            relativeLayout.Clicked += async (sender, args) =>
                await Navigation.PushAsync(new RelativeLayoutView());

            Button scrollView = new Button
            {
                Text = " ScrollView ",
                Font = Font.SystemFontOfSize(NamedSize.Large),
                BorderWidth = 1
            };

            scrollView.Clicked += async (sender, args) =>
                await Navigation.PushAsync(new ScrollViewPageView());

            Button absoluteLayout = new Button
            {
                Text = " AbsoluteLayout ",
                Font = Font.SystemFontOfSize(NamedSize.Large),
                BorderWidth = 1
            };

            absoluteLayout.Clicked += async (sender, args) =>
                await Navigation.PushAsync(new AbsoluteLayoutView());

            Button frame = new Button
            {
                Text = " Frame ",
                Font = Font.SystemFontOfSize(NamedSize.Large),
                BorderWidth = 1
            };

            frame.Clicked += async (sender, args) =>
                await Navigation.PushAsync(new FrameView());

            Content = new StackLayout
            {
                Children =
                {
                    header,
                    stackLayout,
                    grid,
                    relativeLayout,
                    scrollView,
                    absoluteLayout,
                    frame
                }
            };
        }
    }
}