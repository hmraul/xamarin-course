﻿using Xamarin.Forms;

namespace Xamarin_Forms_Layouts.Views
{
    public class FrameView : ContentPage
    {
        public FrameView()
        {
            Label header = new Label
            {
                Text = "Frame",
                FontSize = 50,
                FontAttributes = FontAttributes.Bold,
                HorizontalOptions = LayoutOptions.Center
            };

            Frame frame = new Frame
            {
                OutlineColor = Color.Accent,
                HasShadow = true,
                HorizontalOptions = LayoutOptions.Center,
                VerticalOptions = LayoutOptions.CenterAndExpand,
                Content = new Label
                {
                    Text = "En frame!"
                }
            };

            this.Content = new StackLayout
            {
                Children =
                {
                    header,
                    frame
                }
            };
        }
    }
}
