﻿using Xamarin.Forms;

namespace Xamarin_Forms_Layouts.Views
{
    public class StackLayoutView : ContentPage
    {
        public StackLayoutView()
        {
            Label header = new Label
            {
                Text = "StackLayout",
                FontSize = 50,
                FontAttributes = FontAttributes.Bold,
                HorizontalOptions = LayoutOptions.Center
            };

            StackLayout stackLayout = new StackLayout
            {
                Spacing = 0,
                VerticalOptions = LayoutOptions.FillAndExpand,
                Children =
                {
                    new Label
                    {
                        Text = "StackLayout",
                        HorizontalOptions = LayoutOptions.Start
                    },
                    new Label
                    {
                        Text = "apila sus hijos",
                        HorizontalOptions = LayoutOptions.Center
                    },
                    new Label
                    {
                        Text = "verticalmente",
                        HorizontalOptions = LayoutOptions.End
                    },
                    new Label
                    {
                        Text = "por defecto,",
                        HorizontalOptions = LayoutOptions.Center
                    },
                    new Label
                    {
                        Text = "pero la posición horizontal",
                        HorizontalOptions = LayoutOptions.Start
                    },
                    new Label
                    {
                        Text = "puede ser controlada con",
                        HorizontalOptions = LayoutOptions.Center
                    },
                    new Label
                    {
                        Text = "la propiedad HorizontalOptions.",
                        HorizontalOptions = LayoutOptions.End
                    },
                    new Label
                    {
                        Text = "Opción expandida permite uno o más elementos hijos " +
                               "para ocupar el espacio restante.",
                        VerticalOptions = LayoutOptions.CenterAndExpand,
                        HorizontalOptions = LayoutOptions.End
                    },
                    new StackLayout
                    {
                        Spacing = 0,
                        Orientation = StackOrientation.Horizontal,
                        Children =
                        {
                            new Label
                            {
                                Text = "La apilación",
                            },
                            new Label
                            {
                                Text = "puede ser también",
                                HorizontalOptions = LayoutOptions.CenterAndExpand
                            },
                            new Label
                            {
                                Text = "horizontal.",
                            },
                        }
                    }
                }
            };

            this.Content = new StackLayout
            {
                Children =
                {
                    header,
                    stackLayout
                }
            };
        }
    }
}