﻿using Xamarin.Forms;
using Xamarin_Forms_Layouts.Views;

namespace Xamarin_Forms_Layouts
{
    public class App : Application
    {
        public App()
        {
            MainPage = new NavigationPage(new MainView());
        }

        protected override void OnStart()
        {
            // Handle when your app starts
        }

        protected override void OnSleep()
        {
            // Handle when your app sleeps
        }

        protected override void OnResume()
        {
            // Handle when your app resumes
        }
    }
}
