﻿using System.Windows.Input;
using Xamarin.Forms;

namespace HolaMVVM.ViewModels
{
    public class MainViewModel : BindableObject
    {
        private int _counter;
        private string _message;

        public ICommand ClicCommand { get { return new Command(ButtonClic); } }

        public string Message
        {
            get { return _message; }
            set
            {
                _message = value;
                OnPropertyChanged("Message");
            }
        }

        private void ButtonClic()
        {
            _counter++;

            Message = string.Format("Botón pulsado {0} veces", _counter);
        }
    }
}
