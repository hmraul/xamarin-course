﻿using HolaMVVM.ViewModels;
using Xamarin.Forms;

namespace HolaMVVM.Views
{
    public partial class MainView : ContentPage
    {
        public MainView()
        {
            InitializeComponent();

            BindingContext = new MainViewModel();
        }
    }
}
