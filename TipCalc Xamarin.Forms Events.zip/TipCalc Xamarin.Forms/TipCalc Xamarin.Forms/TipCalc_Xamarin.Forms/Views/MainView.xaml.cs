﻿using System;
using TipCalc_Xamarin.Forms.Models;
using Xamarin.Forms;

namespace TipCalc_Xamarin.Forms.Views
{
    public partial class MainView : ContentPage
    {
        TipInfo info = new TipInfo()
        {
            TipPercent = 15
        };

        public MainView()
        {
            InitializeComponent();

            TipPercent.Text = info.TipPercent.ToString();
            TipPercentSlider.Value = Convert.ToDouble(info.TipPercent);
            
            info.TipValueChanged += (sender, e) =>
            {
                TipValue.Text = info.TipValue.ToString();
                Total.Text = (info.TipValue + info.Total).ToString();
            };

            ReceiptTotal.TextChanged += (sender, e) =>
            {
                info.Total = Parse(ReceiptTotal.Text);
            };

            TipPercent.TextChanged += (sender, e) =>
            {
                info.TipPercent = Parse(TipPercent.Text);
            };

            Subtotal.TextChanged += (sender, e) =>
            {
                info.Subtotal = Parse(Subtotal.Text);
            };

            TipPercentSlider.ValueChanged += (sender, e) =>
            {
                TipPercent.Text = e.NewValue.ToString();
                TipPercentSlider.Value = e.NewValue;
            };
        }

        static decimal Parse(string text)
        {
            if (string.IsNullOrEmpty(text))
                return 0m;

            try
            {
                return Convert.ToDecimal(text);
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine(e.Message);

                return 0m;
            }
        }
    }
}